import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("Tiendas", "0001_initial"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[],
            state_operations=[
                migrations.DeleteModel(name="Shop"),
                migrations.CreateModel(
                    name="Shop",
                    fields=[
                        (
                            "id",
                            models.BigAutoField(
                                auto_created=True,
                                primary_key=True,
                                serialize=False,
                                verbose_name="ID",
                            ),
                        ),
                        ("nombre", models.CharField(max_length=100)),
                        ("telefono", models.CharField(max_length=15)),
                        ("email", models.EmailField(max_length=254)),
                        ("departamento", models.CharField(max_length=50)),
                        ("municipio", models.CharField(max_length=50)),
                        ("horario", models.CharField(max_length=100)),
                        (
                            "direccion",
                            models.CharField(blank=True, max_length=255, null=True),
                        ),
                        ("descripcion", models.TextField(blank=True, null=True)),
                        ("created_at", models.DateTimeField(auto_now_add=True)),
                        (
                            "owner",
                            models.ForeignKey(
                                blank=True,
                                null=True,
                                on_delete=django.db.models.deletion.CASCADE,
                                related_name="shops",
                                to=settings.AUTH_USER_MODEL,
                            ),
                        ),
                    ],
                    options={
                        "db_table": "usuarios_shop",
                    },
                ),
            ],
        ),
    ]
